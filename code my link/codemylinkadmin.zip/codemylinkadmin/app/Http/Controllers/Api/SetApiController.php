<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SetApiController extends Controller
{

    function adddata(Request $req){

        $task = $req->input('task');
        $id = $req->input('id');

        if(isset($task) && isset($id) && $task == 'createuserdata'){

            $fireid=$id;
            $name=$req->input('name');
            $email=$req->input('email');
            $phone=$req->input('phone');

            if(isset($name) && isset($email) && isset($phone)){

                $result = DB::insert("INSERT INTO tbluserdata (fireid, name, email, phone)
                VALUES 
                ('$fireid', '$name', '$email', '$phone')");

                if($result){

                    return ["result"=>"Success","status"=>"1","data"=>"User created Successfully"];

                } else{

                    return ["result"=>"failed","status"=>"0","data"=>"user not created... please try again"];

                }

            }
            
        }

        if(isset($task) && isset($id) && $task == 'codemylink'){
           
            $link = $req->input('link');
            $title = $req->input('title');
            $des = $req->input('des');

            $userid=$req->input('userid');;
            $fireid = $id;
            
            if(!isset($fireid)){

                return "fire id not set";

            }

            $checkisuser= DB::select("select * from tbluserdata where id='$userid'");

            if($checkisuser){

                $userfireid=$checkisuser[0]->fireid;

                if($userfireid != $fireid){
                    return ;
                }

            }else{
                return;
            }

        


            if(isset($link) && isset($title) && isset($des)){

                ///generate random code for link

                for ($i=0;$i<=101;$i++){
                    // $uniqid = substr(md5(microtime()),rand(0,26),7);
                    $uniqcode= uniqid();

                    $checkisnotuniq=DB::select("select  id from tblcodeforlinks where code ='$uniqcode'");

                    if($checkisnotuniq){

                        if($i==101){
    
                            return ["result"=>"Failed","status"=>"-1","data"=>"uniq code is not generate. Please try again"];
                        
                        }
                        

                    } else{

                        // insert data
                        $result = DB::insert("INSERT INTO tblcodeforlinks ( userid,status,code, link, title, des, views)
                         VALUES 
                        ('$userid','1','$uniqcode', '$link', '$title', '$des', 0)");

                        if($result){

                            return ["result"=>"Success","status"=>"1","data"=>["code"=>$uniqcode,"link"=>$link]];
            
                        } else{
            
                            return ["result"=>"failed","status"=>"0","data"=>"failded"];
            
                        }

                        break;

                    }


                }
            
            }

        }

       

    }

}