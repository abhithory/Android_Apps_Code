<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GetApiController extends Controller
{
    function getData(Request $req){

        $task = $req->input('task');
        $id = $req->input('id');

        if(isset($task) && $task == 'getuserdata'){

            $fireid=$id;

            $result = DB::select("select * from tbluserdata where fireid='$fireid'");

            if($result){

                return ["result"=>"Success","status"=>"1","data"=>$result];

            } else{

                return ["result"=>"failed","status"=>"0","data"=>$result];

            }


        }


        if(isset($task) && isset($id) && $task == 'linkbycode'){

            $code=$id;

            $result = DB::select("select * from tblcodeforlinks where code = '$code'");


            if($result){

                $result = $result[0];

                $status =$result->status;

                if($status !=1){

                    $result=["status"=>$status];
                } else {

                    // update view

                    $updateview=DB::update("UPDATE tblcodeforlinks SET views =views+1 WHERE code = '$code'");

                }

                return ["result"=>"Success","status"=>"1","data"=>$result];

            } else{

                return ["result"=>"failed","status"=>"0","data"=>"code does not exist"];

            }



        }

        if(isset($task) && $task == 'getappconfig'){




            $result = DB::select("SELECT * FROM tblapp_confi")[0];

        
            if($result){

                return ["result"=>"Success","status"=>"1","data"=>$result];

            } else{

                return ["result"=>"failed","status"=>"0","data"=>$result];

            }

            
           

        }


        if(isset($task) && isset($id) && $task == 'getmylinks5'){

            $fireid=$id;

            $userid=$req->input('userid');


            $checkisuser= DB::select("select * from tbluserdata where id='$userid'");

            if($checkisuser){

                $userfireid=$checkisuser[0]->fireid;

                if($userfireid != $fireid){
                    return ;
                }

            }else{
                return ;
            }


            if(true){

                // $result = DB::select("select * from tblcodeforlinks where userid = '$userid'");

                    $result = DB::table('tblcodeforlinks')->where("userid","=",$userid)->orderBy('id', 'DESC')->paginate(5);


                    if($result){
                
                        return ["result"=>"Success","status"=>"1","data"=>$result];

                    } else{

                        return ["result"=>"failed","status"=>"0","data"=>"code does not exist"];

                    }



            }

        }

        if(isset($task) && isset($id) && $task == 'getmylinks15'){

            $fireid=$id;

            $userid=$req->input('userid');


            $checkisuser= DB::select("select * from tbluserdata where id='$userid'");

            if($checkisuser){

                $userfireid=$checkisuser[0]->fireid;

                if($userfireid != $fireid){
                    return "fire id doesnot math";
                }

            }else{
                return "not any user with this userid";
            }


            if(true){

                // $result = DB::select("select * from tblcodeforlinks where userid = '$userid'");

                    $result = DB::table('tblcodeforlinks')->where("userid","=",$userid)->orderBy('id', 'DESC')->paginate(15);


                    if($result){
                
                        return ["result"=>"Success","status"=>"1","data"=>$result];

                    } else{

                        return ["result"=>"failed","status"=>"0","data"=>"code does not exist"];

                    }



            }

        }

    }

    

}
