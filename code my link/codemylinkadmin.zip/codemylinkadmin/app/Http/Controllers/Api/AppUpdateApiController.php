<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AppUpdateApiController extends Controller
{
    function appupdate(Request $req){

        $task = $req->input('task');

        if(isset($task) && $task == 'appupdatedata'){

            $result = DB::select("SELECT * FROM tblappupdate")[0];

        
            if($result){

                return ["result"=>"Success","status"=>"1","data"=>$result];

            } else{

                return ["result"=>"failed","status"=>"0","data"=>$result];

            }


        }

        if(isset($task) && $task == 'forappdata'){

            $result = DB::select("SELECT * FROM tblforappdata")[0];

        
            if($result){

                return ["result"=>"Success","status"=>"1","data"=>$result];

            } else{

                return ["result"=>"failed","status"=>"0","data"=>$result];

            }


        }



    }

}
