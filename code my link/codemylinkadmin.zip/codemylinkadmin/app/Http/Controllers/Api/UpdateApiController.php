<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UpdateApiController extends Controller
{
   

    function updateData(Request $req){

        $task = $req->input('task');
        $id = $req->input('id');
    

        if(isset($task) && isset($id) && $task == 'updateuserdata'){
            $name=$req->input('name');
            $phone=$req->input('phone');
            $fireid=$id;
            $userid=$req->input('userid');

            if(isset($name) && isset($phone) && isset($fireid)){

                $result=DB::update("UPDATE tbluserdata SET name = '$name', phone = '$phone' WHERE id='$userid' && fireid='$fireid'");
                

                if($result){

                    return ["result"=>"Success","status"=>"1","data"=>"User data updated Successfully"];

                } else{

                    return ["result"=>"failed","status"=>"0","data"=>"user data not updated... please try again"];

                }

            }


        }

        if(isset($task) && isset($id) && $task == 'updatecodedata'){
            $code=$req->input('code');
            $link=$req->input('link');
            $title=$req->input('title');
            $des=$req->input('des');
            $userid=$req->input('userid');
            $status=$req->input('status');
            $fireid=$id;


            if(!isset($fireid)){
                return "fire id not set";
            }

            $checkisuser= DB::select("select * from tbluserdata where id='$userid'");

            if($checkisuser){

                $userfireid=$checkisuser[0]->fireid;

                if($userfireid != $fireid){
                    return ;
                }

            }else{
                return;
            }

            if(isset($link) && isset($title) && isset($des) && isset($code) && isset($status)){


                $result = DB::update("UPDATE tblcodeforlinks SET 
                status ='$status', link ='$link', title ='$title', des='$des'
                 WHERE code='$code' && userid='$userid'
                ");

                        if($result){

                            return ["result"=>"Success","status"=>"1","data"=>"Code data Updated Successfully"];
            
                        } else{
            
                            return ["result"=>"failed","status"=>"0","data"=>"Code data not Updated"];
            
                        }



            }




        }

    }



}
