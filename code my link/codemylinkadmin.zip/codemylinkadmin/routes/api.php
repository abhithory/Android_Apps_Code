<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AppUpdateApiController;
use App\Http\Controllers\Api\GetApiController;
use App\Http\Controllers\Api\SetApiController;
use App\Http\Controllers\Api\UpdateApiController;
use App\Http\Controllers\Api\DeleteApiController;
use App\Http\Controllers\Api\AppEarningController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});


Route::post('setdata_cml', [SetApiController::class,"addData"]);

Route::post('getdata_cml', [GetApiController::class,"getData"]);

Route::post('updatedata_cml',[UpdateApiController::class,"updateData"]);

Route::post('cmlappupdate',[AppUpdateApiController::class,"appupdate"]);

Route::post('cmlearn',[AppEarningController::class,""]);