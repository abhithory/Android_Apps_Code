package com.sauapps.lungstesterapp;

import android.content.Context;

public class MyTimer implements Runnable {


    private static final long MILLIES_TO_SEC = 1000;
    private static final long MILLIES_TO_MIN = 60000;
    private static final long MILLIES_TO_HOURS = 3600000;

    private Context context;

    private long myStartTime;


    private Boolean isRunning;

    public MyTimer(Context context) {
        this.context = context;
    }
    public void start(){
        myStartTime = System.currentTimeMillis();
        isRunning = true;
    }

    public void  stop(){
        isRunning =false;
    }

    @Override
    public void run() {

        while (isRunning){

            long since = System.currentTimeMillis() - myStartTime;

            int milis = (int) (since % 1000);
            int seconds = (int) ((since/MILLIES_TO_SEC));

            if (since == config.Total_test_time){

                ((MainActivity) context).updateTimer(String.format(
                        "%03d:%3d", seconds, milis
                ), since);

                stop();

//                ((MainActivity)context).stopTest();
            }else {

                ((MainActivity) context).updateTimer(String.format(
                        "%02d:%3d", seconds, milis
                ), since);

            }


        }


    }
}
