package com.sauapps.lungstesterapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;

import android.app.Dialog;
import android.content.Intent;
import android.content.IntentSender;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.android.play.core.tasks.Task;
import com.sauapps.lungstesterapp.databinding.ActivityMainBinding;


public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener  {

    private boolean isStart = false;


    public static final String applink = "https://play.google.com/store/apps/details?id=com.sauapps.lungstesterapp";

    private TextView timer;
    private TextView ma_round_count, ma_user_performance_b;
    private Button start_dialog_for_test_b;


    private long total_time_mili;

    private Dialog start_test_dialog;
    private Button start_test_final_dialog_b;


    private Dialog result_dialog;
    private TextView trd_result_score;
    private TextView trd_lungs_status;
    private Button trd_again_test_b;

    private TextView trd_total_rounds;
    private Button share_app_B;


    private static final long MILLIES_TO_SEC = 1000;
    private MyTimer myTimer;
    private Thread myThred;

    private ActivityMainBinding activityMainBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        activityMainBinding = ActivityMainBinding.inflate(getLayoutInflater());

        setTheme(R.style.Theme_LungsTester);
        setContentView(activityMainBinding.getRoot());

        checkAppUpdate();

        bindview();

        events();
        navigationDrawer();


    }

    private void checkAppUpdate() {

        AppUpdateManager appUpdateManager = AppUpdateManagerFactory.create(this);

// Returns an intent object that you use to check for an update.
        Task<AppUpdateInfo> appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();

// Checks that the platform will allow the specified type of update.
        appUpdateInfoTask.addOnSuccessListener(appUpdateInfo -> {
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                    // This example applies an immediate update. To apply a flexible update
                    // instead, pass in AppUpdateType.FLEXIBLE
                    && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {

                try {
                    appUpdateManager.startUpdateFlowForResult(appUpdateInfo, AppUpdateType.IMMEDIATE, MainActivity.this, 1122);
                } catch (IntentSender.SendIntentException e) {
                    e.printStackTrace();
                }
                // Request the update.
            }
        });

    }

    private void bindview() {
        timer = activityMainBinding.timerClock;
        start_dialog_for_test_b = activityMainBinding.startTimer;
        ma_round_count = activityMainBinding.maRoundsCount;
        ma_user_performance_b = activityMainBinding.userPerformation;


        start_test_dialog = new Dialog(this);
        start_test_dialog.setContentView(R.layout.start_test_dialog);
        start_test_dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        start_test_final_dialog_b = start_test_dialog.findViewById(R.id.start_test);


        result_dialog = new Dialog(this);
        result_dialog.setContentView(R.layout.test_result_dialog);
        result_dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        trd_again_test_b = result_dialog.findViewById(R.id.trd_test_again_b);
        trd_result_score = result_dialog.findViewById(R.id.trd_time_taked);
        trd_lungs_status = result_dialog.findViewById(R.id.trd_lungs_status);
        trd_total_rounds = result_dialog.findViewById(R.id.trd_total_rounds);
        share_app_B = result_dialog.findViewById(R.id.trd_share_app_b);


    }

    private void navigationDrawer() {

        activityMainBinding.homeNavigation.bringToFront();
        activityMainBinding.homeNavigation.setNavigationItemSelectedListener(this);


        activityMainBinding.hamburgerIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (activityMainBinding.drawerLayout.isDrawerVisible(GravityCompat.END)) {
                    activityMainBinding.drawerLayout.closeDrawer(GravityCompat.END);
                } else {
                    activityMainBinding.drawerLayout.openDrawer(GravityCompat.END);

                }

            }
        });


    }

    private void events() {

        start_dialog_for_test_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isStart) {
                    stopTest();
                } else {
                    start_test_dialog.show();
                }

            }
        });


        start_test_final_dialog_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                start_test_dialog.dismiss();
                isStart = true;

                activityMainBinding.circleProgress.startAnimation(AnimationUtils.loadAnimation(MainActivity.this, R.anim.translate_dot));
                activityMainBinding.maClockBallForRotate.startAnimation(AnimationUtils.loadAnimation(MainActivity.this, R.anim.rotating_animation));

                myTimer = new MyTimer(MainActivity.this);
                myThred = new Thread(myTimer);
                myThred.start();
                myTimer.start();

                start_dialog_for_test_b.setText("Stop Test");
                start_dialog_for_test_b.setBackground(getDrawable(R.drawable.custom_button_stop));


            }
        });

        trd_again_test_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                result_dialog.dismiss();

            }
        });

        ma_user_performance_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(MainActivity.this, "Soon...", Toast.LENGTH_SHORT).show();

                /// add bottom sheet for previous results...

            }
        });

    }


    public void stopTest() {

        myTimer.stop();
        myThred.interrupt();
        myThred = null;
        myTimer = null;

        isStart = false;

        activityMainBinding.circleProgress.clearAnimation();
        activityMainBinding.maClockBallForRotate.clearAnimation();


        start_dialog_for_test_b.setText("Start Lungs Test");
        start_dialog_for_test_b.setBackground(getDrawable(R.drawable.custom_button_heading));


        setScore();

    }


    private void setScore() {

        int full_rounds = (int) ((total_time_mili / MILLIES_TO_SEC) / 10);
        int remained_sec = (int) ((total_time_mili / MILLIES_TO_SEC) % 10);

        int remained_round = 0;


        if (remained_sec <= 2) {

            remained_round = 0;

        } else if (remained_sec <= 4) {
            remained_round = 3;


        } else if (remained_sec <= 8) {

            remained_round = 6;

        } else if (remained_sec < 10) {

            remained_round = 9;

        }

        int time_taked_in_sec = (int) ((total_time_mili / MILLIES_TO_SEC));
        trd_result_score.setText(String.valueOf(time_taked_in_sec) + " sec");

        if (remained_round == 0) {

            trd_total_rounds.setText(String.valueOf(full_rounds));

        } else {

            trd_total_rounds.setText(String.valueOf(full_rounds) + "." + String.valueOf(remained_round));

        }


        if (full_rounds <= 2) {
            trd_lungs_status.setText(getString(R.string.weak_lungs));
            trd_lungs_status.setTextColor(getResources().getColor(R.color.red_weak_lungs));
        } else if (full_rounds <= 4) {
            trd_lungs_status.setText(getString(R.string.normal_lungs));
            trd_lungs_status.setTextColor(getResources().getColor(R.color.yello_dark_Normal_lungs));

        } else if (full_rounds <= 8) {
            trd_lungs_status.setText(getString(R.string.strong_lungs));
            trd_lungs_status.setTextColor(getResources().getColor(R.color.yello_strong_lungs));

        } else if (full_rounds <= 10) {

            trd_lungs_status.setText(getString(R.string.super_strong_lungs));
            trd_lungs_status.setTextColor(getResources().getColor(R.color.green_super_strong_lungs));

        }

        result_dialog.show();

        share_app_B.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(MainActivity.this, "Sharing... Please wait..", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT,"Test your lungs capacity By using this app \n"+applink+ "\n\n My Performance: "+ String.valueOf(full_rounds)+"\n \nStay Safe and Healthy" );

                startActivity(intent.createChooser(intent,"Share"));
            }
        });

    }

    public void updateTimer(String updatetime, long time_mili) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                timer.setText(updatetime);
                total_time_mili = time_mili;

                int full_rounds = (int) ((time_mili / MILLIES_TO_SEC) / 10);

                ma_round_count.setText(String.valueOf(full_rounds));


                if (time_mili == config.Total_test_time) {


                    stopTest();

                }


            }
        });
    }

    private void rateusOnPlaystore() {

        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(String.valueOf(applink)));
        startActivity(browserIntent);


    }


    @Override
    public void onBackPressed() {
        if (activityMainBinding.drawerLayout.isDrawerVisible(GravityCompat.END)) {
            activityMainBinding.drawerLayout.closeDrawer(GravityCompat.END);
        } else {
            super.onBackPressed();
        }

    }

    @Override
    protected void onResume() {
        super.onResume();

        checkAppUpdate();
    }


    @Override
    public boolean onNavigationItemSelected( MenuItem item) {
        switch (item.getItemId()) {

            case R.id.hn_rate_on_playstore:

                rateusOnPlaystore();
                return false;

            case R.id.hn_share:

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT,"Test your lungs capacity By using this app \n"+applink+"\n \nStay Safe and Healthy");

                startActivity(intent.createChooser(intent,"Share"));



            return false;

            case R.id.hn_aboutus:

                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://sauappsteam.blogspot.com/p/about-us-lungs-tester-app.html"));
                startActivity(browserIntent);

                return false;

            case R.id.hn_pp:

                Intent browserIntent2 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://sauappsteam.blogspot.com/p/privacy-policy-for-lungs-tester-app.html"));
                startActivity(browserIntent2);

                return false;


        }
        return true;

    }




}