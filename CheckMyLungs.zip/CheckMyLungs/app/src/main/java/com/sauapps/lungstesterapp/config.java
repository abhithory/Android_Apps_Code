package com.sauapps.lungstesterapp;

public class config {

    public static int Total_test_time = 100000;

}
